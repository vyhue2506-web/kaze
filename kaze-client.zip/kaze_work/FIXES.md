# Fix pass 3 — Minecraft 1.21.11 (Yarn 1.21.11+build.4)

NOT compiled or run (no Gradle / no network in the review environment). Everything below was checked
against the Yarn 1.21.11 docs where noted; build with `gradlew build` on JDK 21 and send back the log.

## Runtime bugs fixed (would have broken modules even after compiling)
- KeyboardMixin / MouseMixin used the pre-1.21.9 signatures -> keybinds, ClickGUI toggle and every
  key-activated module were dead. Now `Keyboard.onKey(long,int,KeyInput)` / `Mouse.onMouseButton(long,MouseInput,int)` (verified).
- TickEvent was fired twice per tick (MinecraftClientMixin + ClientPlayerEntityMixin) -> every module ran 2x. Removed the duplicate.
- Kaze ctor: `mc` was assigned last and any exception was swallowed -> half-initialised client. Reordered + errors printed.
- CameraMixin: `Camera.update` takes `World` (not `BlockView`) in 1.21.11 -> Freecam hook would not apply (verified).
- PlayerESP / StorageESP: NPE every frame when `crosshairTarget` is null (tracers). Fixed; PlayerESP rewritten.
- client.mixins.json: `defaultRequire` 1 -> 0 so one stale hook cannot crash the game on launch. Check latest.log for Mixin warnings.

## Port work
- GUI input (ClickGUI, StringBox, ItemFilter) moved to `KeyInput` / `Click` / `CharInput` (1.21.9+ API).
- RenderUtils rewritten on `DrawContext.fill` (rounded rects/circles/outlines, item draw) - old code used removed
  RenderSystem/Tessellator and contained raw intermediary names (class_286, method_34540, field_4344).
- 3D overlay: renderLine / renderFilledBox project world points to screen (Render3DEvent now fired from InGameHudMixin).
  Depth is ignored (through-walls) and FOV is the option value (no sprint FOV change).
- TextRenderer: vanilla font at 2x. Custom TTF renderer (GlyphPage*) deleted; "Custom Font" setting is now a no-op.
- ChunkFinder toast replaced by a chat message. TargetHUD skin draw uses `SkinTextures` overload (verified).
- ModuleButton scissor via `DrawContext.enableScissor`.

## Disabled
- NetheriteFinder, Ore, HeightContextMixin and the 3 placement-modifier accessors moved to `_disabled_needs_port/`
  (need ChunkRandom / PlacedFeatureIndexer worldgen port).

## Untouched / unverified
- SelfDestruct (not modified, not reviewed further).
- EntityRenderDispatcherMixin (hitbox render), TextVisitFactoryMixin, ChunkOcclusionDataBuilderMixin, Frustum accessor, WorldChunkMixin:
  targets not checked against 1.21.11 mappings.
- Combat/donut/misc modules were only checked for event wiring, not line-by-line against 1.21.11 APIs.

## Font restore (pass 4)
- font.ttf (Minecraft Ten) moved to assets/kaze/font/font.ttf and registered by assets/kaze/font/custom.json (ttf provider + vanilla fallback).
- TextRenderer now draws Text with that font when the "Custom Font" setting is on (vanilla font when off). Widths use the same Text so boxes stay aligned.
- NOT compiled. The only risky line is TextRenderer.customStyle(): `Style.withFont(new StyleSpriteSource.Font(id))` (1.21.9+ Yarn name). If it fails to compile, check the Yarn name of FontDescription/StyleSpriteSource.
- Tune size/position in custom.json: "size" (7.14 = 1 font pixel per GUI pixel) and "shift" [x, y].

## ChunkFinder toast (pass 5)
- ChunkFinder found-notification is now a vanilla top-right toast (utils/ToastUtil -> SystemToast), title "Chunk Finder (N found)", body "X: .. Z: ..".
- All toasts share one SystemToast.Type, so a burst of finds updates the visible toast instead of queueing 5+ popups (N counts all finds).
- New settings: "Toast" (default on), "Chat Message" (default off). If the toast fails at runtime, it falls back to chat.
- NOT compiled. Risky lines (all in ToastUtil): `new SystemToast.Type(6000L)` and `SystemToast.add(ToastManager, Type, Text, Text)`. If the constructor isn't public in your Yarn build, use `SystemToast.Type.PERIODIC_NOTIFICATION` instead.

## Krypton+ modules (pass 6)
- The README in KryptonPlus_4_modules_only mislabeled 3 of the 4 files. Decoding their strings shows:
  StorageESP.java = Storage ESP (correct), BlockESP.java = "No Hit Delay", PlayerESP.java = "Auto Log", AutoInvTotem.java = "Auto Eat".
- Auto Eat already exists in this client with the same settings (Health/Hunger Threshold) -> nothing to replace.
- New: combat/NoHitDelay (Only Item, Item, Air, Blocks, Whitelist Blocks) and misc/AutoLog (Player Distance, Webhook, Ignore Friends + Friends list). Registered in ModuleManager.
- StorageESP: fixed unbalanced matrix push/pop and camera NPE when camera is null, skips block entities that are not enabled storage types (no more invisible boxes/tracers).
- Logic of the new modules is rebuilt from decoded setting names and imports (method calls in the Krypton+ files are hidden by invokedynamic), not copied.
- NOT compiled (no Gradle/network here). Correction: the javac syntax check claimed for pass 6 did not actually run (javac was missing); it was run properly in pass 7.

## Rename to Kaze (pass 7)
- Krypton -> Kaze everywhere: package skid.krypton -> skid.kaze (folders moved), main class and client-category module Krypton -> Kaze,
  mod id/name, entrypoint skid.kaze.Main, mixin package, refmap (kaze-refmap.json), assets/krypton -> assets/kaze (font id kaze:font.ttf),
  Gradle rootProject/archivesName/maven_group, HUD watermark and module name ("Krypton+" -> "Kaze"). Project root folder is now kaze_work.
- fabric.mod.json "authors" kept unchanged (credits of the original code).
- Static checks run with javac 21 (no Minecraft jars available): all 138 .java files parse with zero syntax errors; client.mixins.json lists exactly the
  mixin classes that exist; every ModuleManager registration has a class and every module class is registered; no leftover class_/method_/field_ intermediary names.
- Type errors cannot be checked without Minecraft/Yarn jars (about 2100 "missing package/symbol" errors are all from that). Real verification = `gradlew build` on JDK 21.
